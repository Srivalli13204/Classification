#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install scikit-learn==0.23.1')


# In[2]:


#importing libraries


# In[3]:


import pandas as pd
import pylab as pl
import numpy as np
import scipy.optimize as opt
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX8.csv")
df.head()


# In[5]:


ax = df[df['Class'] == 4][0:50].plot(kind='scatter', x='Clump', y='UnifSize', color='DarkBlue', label='malignant');
df[df['Class'] == 2][0:50].plot(kind='scatter', x='Clump', y='UnifSize', color='Yellow', label='benign', ax=ax);
plt.show()


# In[6]:


#data preprocessing


# In[7]:


df.dtypes


# In[8]:


df = df[pd.to_numeric(df['BareNuc'], errors='coerce').notnull()]
df['BareNuc'] = df['BareNuc'].astype('int')
df.dtypes


# In[9]:


feature = df[['Clump', 'UnifSize', 'UnifShape', 'MargAdh', 'SingEpiSize', 'BareNuc', 'BlandChrom', 'NormNucl', 'Mit']]
X = np.asarray(feature)
X


# In[10]:


y = np.asarray(df['Class'])
y


# In[11]:


#train test split


# In[12]:


X_train, X_test, y_train, y_test = train_test_split( X, y, test_size=0.2, random_state=4)


# In[13]:


print ('Train set:', X_train.shape,  y_train.shape)
print ('Test set:', X_test.shape,  y_test.shape)


# In[14]:


#modelling using RBF


# In[15]:


from sklearn import svm
clf = svm.SVC(kernel='rbf')
clf.fit(X_train, y_train) 


# In[16]:


yhat = clf.predict(X_test)
yhat


# In[17]:


#evaluation


# In[18]:


from sklearn.metrics import classification_report, confusion_matrix
import itertools


# In[19]:


def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')
    print(cm)
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


# In[20]:


#computing confusion matrix


# In[21]:


cnf_matrix = confusion_matrix(y_test, yhat, labels=[2,4])
np.set_printoptions(precision=2)


# In[22]:


print (classification_report(y_test, yhat))


# In[23]:


#plotting


# In[24]:


plt.figure()
plot_confusion_matrix(cnf_matrix, classes=['Benign(2)','Malignant(4)'],normalize= False,  title='Confusion matrix')


# In[25]:


#f1_score


# In[26]:


from sklearn.metrics import f1_score
f1_score(y_test, yhat, average='weighted') 


# In[27]:


#jaccard_index


# In[28]:


from sklearn.metrics import jaccard_score
jaccard_score(y_test, yhat,pos_label=2)


# In[29]:


#modelling using linear


# In[30]:


clf2 = svm.SVC(kernel='linear')
clf2.fit(X_train, y_train) 


# In[31]:


#predicting


# In[32]:


yhat2 = clf2.predict(X_test)


# In[33]:


print("F1-score: %.4f" % f1_score(y_test, yhat2, average='weighted'))


# In[34]:


print("Jaccard score: %.4f" % jaccard_score(y_test, yhat2,pos_label=2))


# In[ ]:





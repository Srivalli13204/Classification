#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install scikit-learn==0.23.1')


# In[2]:


#importing libraries


# In[3]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import preprocessing
get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:


#loading the dataset


# In[5]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX5.csv")
df.head()


# In[6]:


#data visualization & analysis


# In[7]:


df['custcat'].value_counts()


# In[8]:


#exploring the data


# In[9]:


df.hist(column = 'income', bins = 50)


# In[10]:


#feature sets


# In[11]:


df.columns


# In[12]:


x = df[['region', 'tenure', 'age', 'marital', 'address', 'income', 'ed',
       'employ', 'retire', 'gender', 'reside']].values
x


# In[13]:


#labels


# In[14]:


y = df['custcat'].values
y


# In[15]:


#normalizing the data


# In[16]:


x = preprocessing.StandardScaler().fit(x).transform(x.astype(float))
x


# In[17]:


#train test split


# In[18]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 4)


# In[19]:


print("Training Set : ", x_train.shape, y_train.shape)
print("Testing Set : ",x_test.shape, y_test.shape)


# In[20]:


#classification


# In[21]:


#import_knn_classifier
from sklearn.neighbors import KNeighborsClassifier


# In[22]:


#training_with_k=4


# In[23]:


k = 4
knn = KNeighborsClassifier(n_neighbors = k).fit(x_train, y_train)
knn


# In[24]:


#prediciting


# In[25]:


predict = knn.predict(x_test)
predict


# In[26]:


#accuracy_evaluation


# In[27]:


from sklearn import metrics
print("Train Set Accuracy : ", metrics.accuracy_score(y_train, knn.predict(x_train)))
print("Test Set Accuracy : ",metrics.accuracy_score(y_test, predict))


# In[28]:


#training_predicting_with_k=6


# In[29]:


k = 6
knn6 = KNeighborsClassifier(n_neighbors = k).fit(x_train, y_train)
predict6 = knn6.predict(x_test)


# In[30]:


print("Train Set Accuracy : ", metrics.accuracy_score(y_train, knn6.predict(x_train)))
print("Test Set Accuracy : ",metrics.accuracy_score(y_test, predict6))


# In[31]:


#for_different_values_of_k


# In[32]:


K = 10
mean = np.zeros((K - 1))
std = np.zeros((K - 1))


# In[33]:


for n in range(1, K):
    knn = KNeighborsClassifier(n_neighbors = n).fit(x_train, y_train)
    predict = knn.predict(x_test)
    mean[n-1] = metrics.accuracy_score(y_test, predict)
    std[n-1] = np.std(predict == y_test) / np.sqrt(predict.shape[0])


# In[34]:


print("Mean Accuracy : ", mean)
print("Standard Accuracy : ", std)


# In[35]:


#plotting for different k values


# In[36]:


plt.plot(range(1, K), mean, 'g')
plt.fill_between(range(1, K), mean - 1 * std, mean + 1 * std, alpha = 0.10)
plt.fill_between(range(1, K), mean - 3 * std, mean + 3 * std, alpha = 0.10, color = 'green')
plt.legend(("Accuracy : ", '=/- 1xstd', '=/- 3xstd'))
plt.xlabel("No.of Neighbors - K ")
plt.ylabel("Accuracy ")
plt.tight_layout()
plt.show()


# In[37]:


print("Best Accuracy :", mean.max(), "with k =", mean.argmax()+1)


# In[38]:


from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score
cm = confusion_matrix(y_test, predict)
accuracy = accuracy_score(y_test, predict)
precision = precision_score(y_test, predict, average='weighted')
recall = recall_score(y_test, predict, average='weighted')
print("Confusion Matrix : ")
print(cm)
print("Accuracy Score : ",accuracy)
print("Precision Score : ",precision)
print("Recall Score : ",recall)


# In[ ]:





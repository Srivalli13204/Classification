#!/usr/bin/env python
# coding: utf-8

# In[1]:


#supress_warnings


# In[2]:


def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn


# In[3]:


#importing the libraries


# In[4]:


import sys
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import sklearn.tree as tree


# In[5]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX6.csv")
df.head()


# In[6]:


#dimensions
df.shape


# In[7]:


#columns
df.columns


# In[8]:


#pre processing


# In[9]:


#feature_matrix
x = df[['Age', 'Sex', 'BP', 'Cholesterol', 'Na_to_K']].values
x


# In[10]:


#using label_encoder_method to convert categorical_to_dummy_variables


# In[11]:


#sex
from sklearn import preprocessing
sex = preprocessing.LabelEncoder()
sex.fit(['F', 'M'])
x[:,1] = sex.transform(x[:,1])


# In[12]:


#BP
Bp = preprocessing.LabelEncoder()
Bp.fit(['LOW','NORMAL','HIGH'])
x[:,2] = Bp.transform(x[:,2])


# In[13]:


#cholesterol
chol = preprocessing.LabelEncoder()
chol.fit(['NORMAL','HIGH'])
x[:,3] = chol.transform(x[:,3])


# In[14]:


x


# In[15]:


#target_variable
y = df['Drug']
y


# In[16]:


#train_test_split


# In[17]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.3, random_state = 3)


# In[18]:


x_train.shape, y_train.shape


# In[19]:


x_test.shape, y_test.shape


# In[20]:


#modelling


# In[21]:


tree = DecisionTreeClassifier(criterion = 'entropy', max_depth = 4)
tree


# In[22]:


#fitting the data


# In[23]:


tree.fit(x_train, y_train)


# In[24]:


#prediction


# In[25]:


predict = tree.predict(x_test)


# In[26]:


print(predict,)
print(y_test)


# In[27]:


#evaluation


# In[28]:


from sklearn import metrics
import matplotlib.pyplot as plt
print("Decision Trees Accuracy :",metrics.accuracy_score(y_test, predict))


# In[30]:


#visualization


# In[29]:


get_ipython().system('conda install -c conda-forge pydotplus -y')
get_ipython().system('conda install -c conda-forge python-graphviz -y')


# In[31]:


#visualize the tree


# In[32]:


from sklearn.tree import export_graphviz
export_graphviz(tree, out_file='tree.dot', filled=True, feature_names=['Age', 'Sex', 'BP', 'Cholesterol', 'Na_to_K'])
get_ipython().system('dot -Tpng tree.dot -o DecisionTree.png')


# In[ ]:





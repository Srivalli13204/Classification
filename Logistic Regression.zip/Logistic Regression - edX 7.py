#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install scikit-learn==0.23.1')


# In[2]:


#importing libraries


# In[3]:


import pandas as pd
import pylab as pl
import numpy as np
import scipy.optimize as opt
from sklearn import preprocessing
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:


#loading the dataset


# In[5]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX7.csv")
df.head()


# In[6]:


#dimensions
df.shape


# In[7]:


#variables
X = np.asarray(df[['tenure', 'age', 'address', 'income', 'ed', 'employ', 'equip']])
X


# In[8]:


y = np.asarray(df['churn'])
y


# In[9]:


#normalizing the dataset


# In[10]:


from sklearn import preprocessing
X = preprocessing.StandardScaler().fit(X).transform(X)
X


# In[11]:


#train test split


# In[12]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split( X, y, test_size=0.2, random_state=4)


# In[13]:


print ('Train set:', X_train.shape,  y_train.shape)
print ('Test set:', X_test.shape,  y_test.shape)


# In[14]:


#modelling


# In[15]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
LR = LogisticRegression(C=0.01, solver='liblinear').fit(X_train,y_train)
LR


# In[16]:


#predicting


# In[17]:


yhat = LR.predict(X_test)
yhat


# In[18]:


#probability


# In[19]:


yhat_prob = LR.predict_proba(X_test)
yhat_prob


# In[20]:


#evaluation


# In[21]:


#jaccard_index
from sklearn.metrics import jaccard_score
jaccard_score(y_test, yhat,pos_label=0)


# In[22]:


#confusion matrix


# In[23]:


from sklearn.metrics import classification_report, confusion_matrix
import itertools


# In[24]:


def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')
    print(cm)
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


# In[25]:


print(confusion_matrix(y_test, yhat, labels=[1,0]))


# In[26]:


#computing confusion matrix


# In[27]:


cnf_matrix = confusion_matrix(y_test, yhat, labels=[1,0])
np.set_printoptions(precision=2)


# In[28]:


#plotting


# In[29]:


plt.figure()
plot_confusion_matrix(cnf_matrix, classes=['churn=1','churn=0'],normalize= False,  title='Confusion matrix')


# In[30]:


print (classification_report(y_test, yhat))


# In[31]:


#log loss


# In[32]:


from sklearn.metrics import log_loss
log_loss(y_test, yhat_prob)


# In[33]:


#different values


# In[34]:


LR2 = LogisticRegression(C=0.01, solver='sag')
LR2.fit(X_train,y_train)


# In[35]:


yhat_prob2 = LR2.predict_proba(X_test)
print ("LogLoss: : %.2f" % log_loss(y_test, yhat_prob2))


# In[ ]:




